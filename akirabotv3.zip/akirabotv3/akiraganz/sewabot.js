const sewabot = () => { 
	return `
*OPEN JASA SEWA BOT*

Sewa Sebulan : 10k
Sewa Permanen : 25k

*Payment :*
_Gopay, Dana,Qris dan Tsel_

Minat?PC
Wa.me/6282158549899
`
}
exports.sewabot = sewabot